package com.ics.part3.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.ics.part3.R;
import com.ics.part3.study.Record;

public class SiteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_site);

        // Get the Record that was passed from StudyActivity
        Bundle extras = getIntent().getExtras();
        Record record = null;
        if (extras != null) {
            record = (Record) extras.getSerializable("record");
        } else {
            Log.d("Error", "No record passed into SiteActivity");
            return;
        }

        // Intent that will be called from the onClick listener below
        final Intent readingIntent = new Intent(SiteActivity.this, ReadingActivity.class);
        readingIntent.putExtra("record", record);

        Button btn1 = findViewById(R.id.continuebutton2);
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(readingIntent);
            }
        });
    }

}
