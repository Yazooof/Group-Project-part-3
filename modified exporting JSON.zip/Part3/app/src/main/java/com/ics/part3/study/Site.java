package com.ics.part3.study;

import java.io.Serializable;
import java.util.*;


public class Site implements Serializable {

	static final long serialVersionUID = 42L;

	private int id;
	private ArrayList<Reading> readings;
	private siteStatus status;

	public enum siteStatus{
		ACTIVE_SITE, SITE_COLLECTION_DISABLED, SITE_INVALID, COMPLETED_STUDY;
	}

	public void setSiteStatus(siteStatus s) {
		status = s;
	}

	public siteStatus getSiteStatus() {
		return status;
	}

	/**
	 * Basic constructor, by default it has no readings, and no collection has started
	 */
	public Site(int id) {
		this.id = id;
		this.readings = new ArrayList<>();
	}


	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * @return the readings
	 */
	public ArrayList<Reading> getReadings() {
		return readings;
	}

	public void clearReadings() {
		this.readings = null;
	}

	/**
	 * @param reading the reading to add
	 */
	public void addReading(Reading reading) {
		this.readings.add(reading);
	}



}
