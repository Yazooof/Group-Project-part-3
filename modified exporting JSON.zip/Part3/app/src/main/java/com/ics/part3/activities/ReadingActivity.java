package com.ics.part3.activities;

import java.io.IOException;
import java.io.OutputStreamWriter;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

import com.ics.part3.R;
import com.ics.part3.study.Record;

public class ReadingActivity extends AppCompatActivity {

    // Record that will be written to JSON on pause or destroy
    Record record = null;

    // Flag that tells us if we should write the file. Set to false after writing, set to
    // true after modifying record. This is so that we don't write twice when onPause() and
    // onDestroy() are both called
    boolean shouldWrite = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reading);

        // Get the Record that was passed from SiteActivity
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            record = (Record) extras.getSerializable("record");
            shouldWrite = true;
        } else {
            Log.d("Error", "No record passed into ReadingActivity");
            return;
        }

        write(record.toJSON());
    }

    @Override
    public void onPause() {
        super.onPause();
        if(shouldWrite) {
            write(record.toJSON());
            shouldWrite = false;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if(shouldWrite) {
            write(record.toJSON());
            shouldWrite = false;
        }
    }

    // TODO Move file writing to fileIO class
    // Writes the Record to a file
    public void write(String data) {
        try {
            OutputStreamWriter outputStreamWriter = new OutputStreamWriter(this.openFileOutput("record.json", Context.MODE_PRIVATE));
            outputStreamWriter.write(data);
            outputStreamWriter.close();
        }
        catch (IOException e) {
            Log.e("EXCEPTION", "File write failed: " + e.toString());
        }
    }
}
