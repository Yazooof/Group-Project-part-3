package com.ics.part3.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.ics.part3.study.*;

import com.ics.part3.R;
import com.ics.part3.study.Record;

import java.util.ArrayList;
import java.util.List;

public class StudyActivity extends AppCompatActivity {

    public static Record record = new Record();//  Stores all the data in the program
    public static int currentStudy;
    public static int currentSite;
    public static ArrayAdapter<String> adapter;
    public static Spinner studySelectSpinner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //Fill Test Data. USE THIS FOR TESTING ONLY.
        record.addStudy(1,"Study 1");
        record.addStudy(2,"Study 2");
        record.addStudy(3,"Study 3");

        record.addSite(1,10);
        record.addSite(1,20);
        record.addSite(1,30);
        record.addSite(2,40);
        record.addSite(2,50);
        record.addSite(2,60);
        record.addSite(3,70);
        record.addSite(3,80);
        record.addSite(3,90);

        record.addReading(1,10,"100", "1/2/2019", Reading.readingType.BAR_PRESS, "50");
        record.addReading(1,10,"200", "1/3/2019", Reading.readingType.BAR_PRESS, "810");
        record.addReading(1,10,"300", "1/4/2019", Reading.readingType.BAR_PRESS, "90");
        record.addReading(1,20,"400", "1/4/2019", Reading.readingType.HUMIDITY, "2062");
        record.addReading(1,20,"500", "1/4/2019", Reading.readingType.HUMIDITY, "65411");
        record.addReading(2,30,"600", "2/8/2019", Reading.readingType.HUMIDITY, "9");
        record.addReading(2,30,"700", "2/1/2019", Reading.readingType.HUMIDITY, "7984");
        record.addReading(2,30,"800", "3/1/2019", Reading.readingType.HUMIDITY, "432");
        record.addReading(2,40,"900", "6/1/2019", Reading.readingType.HUMIDITY, "21");
        record.addReading(2,50,"1000", "6/1/2019", Reading.readingType.HUMIDITY, "48");
        record.addReading(2,60,"1100", "8/1/2019", Reading.readingType.HUMIDITY, "48");
        record.addReading(2,60,"1200", "8/1/2019", Reading.readingType.HUMIDITY, "786");
        record.addReading(2,70,"1300", "8/1/2019", Reading.readingType.HUMIDITY, "4135");
        record.addReading(2,70,"1400", "8/1/2019", Reading.readingType.PARTICULATE, "783");
        record.addReading(3,70,"1500", "8/1/2019", Reading.readingType.PARTICULATE, "7835");
        record.addReading(3,80,"1600", "9/1/2019", Reading.readingType.PARTICULATE, "32");
        record.addReading(3,80,"1700", "10/1/2019", Reading.readingType.PARTICULATE, "7");
        record.addReading(3,80,"1800", "12/1/2019", Reading.readingType.PARTICULATE, "48");
        record.addReading(3,90,"1900", "12/1/2019", Reading.readingType.TEMP, "9456");
        record.addReading(3,90,"2000", "12/1/2019", Reading.readingType.TEMP, "73354");

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Intents that will be called from the onClick overrides below
        final Intent siteIntent = new Intent(StudyActivity.this, SiteActivity.class);
        siteIntent.putExtra("record", record);
        final Intent studyIntent = new Intent(StudyActivity.this, addnewstudy2.class);
        siteIntent.putExtra("record", record);

        Button btn = findViewById(R.id.continuebutton1);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(siteIntent);
            }
        });

        Button btn2 = findViewById(R.id.AddnewstudyButton);
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(studyIntent);
            }
        });

        studySelectSpinner = findViewById(R.id.StudySelectSpinner);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, record.getAllStudyIDs());
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        studySelectSpinner.setAdapter(adapter);
    }

}
