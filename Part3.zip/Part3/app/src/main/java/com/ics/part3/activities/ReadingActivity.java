package com.ics.part3.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.ics.part3.R;

import static com.ics.part3.activities.StudyActivity.record;

public class ReadingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reading);


    }
}
