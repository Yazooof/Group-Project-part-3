package com.ics.part3.study;

import com.google.gson.annotations.SerializedName;

public class Reading {

    @SerializedName("reading_type")
    private String readingType;
    @SerializedName("reading_id")
    private String readingID;
    @SerializedName("reading_value")
    private String readingValue;
    @SerializedName("reading_date")
    private String readingDate;
    @SerializedName("site_id")
	private String siteID;

    // optional
    private String unit;

    public Reading() {
    }

    public Reading(String siteID, String readingType, String readingID, String readingValue) {
        this.siteID= siteID;
        this.readingType = readingType;
        this.readingID = readingID;
        this.readingValue = readingValue;

    }

    public Reading(String siteID, String readingType, String readingID, String readingValue, String readingDate) {
        this.siteID = siteID;
        this.readingType = readingType;
        this.readingID = readingID;
        this.readingValue = readingValue;
        this.readingDate = readingDate;
    }

    public Reading(String siteID, String readingType, String readingID, String readingValue, String readingDate, String unit) {
        this.siteID = siteID;
        this.readingType = readingType;
        this.readingID = readingID;
        this.readingValue = readingValue;
        this.readingDate = readingDate;
        this.unit = unit;
    }


    public String getReading_type() {
        return readingType;
    }


    public void setReading_type(String reading_type) {
        this.readingType = reading_type;
    }


    public String getReading_id() {
        return readingID;
    }


    public void setReading_id(String reading_id) {
        this.readingID = reading_id;
    }


    public String getReading_value() {
        return readingValue;
    }

    public void setReading_value(String reading_value) {
        this.readingValue = reading_value;
    }
    public String getReading_date() {
        return readingDate;
    }


    public void setReading_date(String reading_date) {
        this.readingDate = reading_date;
    }

	public String getSite_id() {
		return siteID;
	}

	public void setSite_id(String site_id) {
		this.siteID = site_id;
	}


    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("reading_type: " + getReading_type() + "\n");
        sb.append("site_id: " + getSite_id() + "\n");
        sb.append("reading_id: " + getReading_id() + "\n");
        sb.append("reading_value: " + getReading_value() + "\n");
        sb.append("reading_date: " + getReading_date() + "\n");
        return sb.toString();
    }

}
