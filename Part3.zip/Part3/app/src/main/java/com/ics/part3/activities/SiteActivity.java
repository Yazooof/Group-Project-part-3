package com.ics.part3.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import com.ics.*;


import com.ics.part3.R;
import com.ics.part3.study.Site;

import java.util.ArrayList;

import static com.ics.part3.activities.StudyActivity.currentSite;
import static com.ics.part3.activities.StudyActivity.currentStudy;
import static com.ics.part3.activities.StudyActivity.record;

public class SiteActivity extends AppCompatActivity {
    public static ArrayAdapter<String> siteAdapter;
    public static Spinner SiteSpinner;

    public static ArrayAdapter<String> siteStatusAdapter;
    public static Spinner siteStatusSpinner;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_site);



        siteAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, record.getAllSiteIDs(currentStudy));
        siteAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        SiteSpinner = (Spinner) findViewById(R.id.SiteID);
        SiteSpinner.setAdapter(siteAdapter);

        Button btn = (Button)findViewById(R.id.AddSiteButton);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SiteActivity.this, AddSiteActivity.class));
            }
        });

        SiteSpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

                        Object item = parent.getItemAtPosition(pos);
                        System.out.println(item.toString());     //prints the text in spinner item.
                        currentSite = Integer.parseInt(item.toString());
                    }
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });

        final ArrayList<String> status = new ArrayList<>();
        status.add(Site.siteStatus.ACTIVE_SITE.toString());
        status.add(Site.siteStatus.COMPLETED_STUDY.toString());
        status.add(Site.siteStatus.SITE_COLLECTION_DISABLED.toString());
        status.add(Site.siteStatus.SITE_INVALID.toString());

        siteStatusAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, status);
        siteStatusAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        siteStatusSpinner = (Spinner) findViewById(R.id.siteStatusSpinner);
        siteStatusSpinner.setAdapter(siteStatusAdapter);

       Button continue2 = (Button)findViewById(R.id.siteContinue);
        continue2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SiteActivity.this, ReadingActivity.class));
            }
        });

        siteStatusSpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {
                        Site.siteStatus n;
                        Object item = parent.getItemAtPosition(pos);
                        if(item.toString().equalsIgnoreCase("ACTIVE_SITE")){
                            n = Site.siteStatus.ACTIVE_SITE;
                        }else if(item.toString().equalsIgnoreCase("COMPLETED_STUDY")){
                            n=Site.siteStatus.COMPLETED_STUDY;
                        }else if(item.toString().equalsIgnoreCase("SITE_COLLECTION_DISABLE")){
                            n=Site.siteStatus.SITE_COLLECTION_DISABLED;
                        }else{
                            n=Site.siteStatus.SITE_INVALID;
                        }
                        record.setSiteStatus(currentStudy, currentSite, n);

                    }
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });
    }

}
