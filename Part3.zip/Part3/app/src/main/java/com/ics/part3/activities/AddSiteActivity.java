package com.ics.part3.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;

import com.ics.part3.R;
import com.*;

import static com.ics.part3.activities.SiteActivity.SiteSpinner;
import static com.ics.part3.activities.SiteActivity.siteAdapter;
import static com.ics.part3.activities.StudyActivity.currentStudy;
import static com.ics.part3.activities.StudyActivity.record;
import static com.ics.part3.activities.StudyActivity.studySelectSpinner;

public class AddSiteActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_site);

        Button btn = (Button)findViewById(R.id.enterSiteIDBtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText siteidEdit = (EditText) findViewById(R.id.enterSiteIDEditText);


                record.addSite(currentStudy, Integer.parseInt(siteidEdit.getText().toString()));
                siteAdapter.add(siteidEdit.getText().toString());

                SiteSpinner.setAdapter(siteAdapter);



                startActivity(new Intent(AddSiteActivity.this, SiteActivity.class));            }
        });

    }
}
