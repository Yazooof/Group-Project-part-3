package com.ics.part3.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.ics.part3.R;

import static com.ics.part3.activities.SiteActivity.siteSpinner;
import static com.ics.part3.activities.SiteActivity.siteAdapter;
import static com.ics.part3.activities.StudyActivity.currentStudy;
import static com.ics.part3.activities.StudyActivity.record;

public class AddSiteActivity extends AppCompatActivity {

    private AlertDialog dialog;
    private EditText siteidEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_site);

        final AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);

        siteidEdit = (EditText) findViewById(R.id.enterSiteIDEditText);


        Button btn = (Button)findViewById(R.id.enterSiteIDBtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(siteidEdit.getText().toString().equalsIgnoreCase(""))
                {
                    builder.setMessage("Site ID cannot be empty ").setTitle("Empty Field Error");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // User clicked OK button
                        }
                    });

                    dialog = builder.create();
                    dialog.show();
                } else
                {
                    record.addSite(currentStudy, siteidEdit.getText().toString());
                    siteAdapter.add(siteidEdit.getText().toString());

                    siteSpinner.setAdapter(siteAdapter);



                    startActivity(new Intent(AddSiteActivity.this, SiteActivity.class));
                }

            }
        });

    }
}
