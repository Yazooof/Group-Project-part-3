package com.ics.part3.study;

import java.util.*;
import com.ics.part3.study.*;

public class Record {
    private ArrayList<Study> studyList = new ArrayList<>();

    //Add single study to study list.
    public String addStudy(int studyID, String studyName) {
        String message = null;
        if((studyName == null)) {
            message = "Invalid study entry\n";
        }else {
            Study newStudy = new Study(studyID, studyName);
            Boolean found = false;
            if(studyList.isEmpty()) {

            }else {
                for (Study study : studyList) {
                    if(study.getStudyID() == studyID) {
                        message = "Study already added\n";
                        found = true;
                        break;
                    }
                }
            }

            if(found == false) {
                studyList.add(newStudy);
                message = "Study added";

            }
        }
		return message;
    }

    //Remove single study from study list. returns boolean true if removed and false if not.
    public boolean removeStudy(int studyID) {
    	for (Study study : studyList) {
			if(study.getStudyID() == studyID) {
				study.setStudyID(0);
				study.setStudyName(null);
				return true;
			}else {
				return false;
			}
		}
		return false;
    }

    //Add a single site to a given study then return message
    public String addSite(int studyID, String siteID) {

    	String message = null;

		Site newSite = new Site(siteID);

		boolean found = false;

		for (Study study : studyList) {
			if(study.getStudyID() == studyID) {
				for (Site site : study.getSites()) {
					if(site.getId().equals(siteID)) {

						message = "Site already exists\n";
						found = true;
					}
				}

				if(!found) {
					message = "New site added\n";
					study.addSite(newSite);
				}
			}
		}
		return message;

    }

    //Removes a site from a given study and returns true if site was removed.
    public boolean removeSite(int studyID, int siteID) {
    	boolean flag = false;
    	for (Study study : studyList) {
			if(study.getStudyID() == studyID) {
				for (Site site : study.getSites()) {
					if(site.getId().equals( siteID)) {
						site.setId("0");
						site.setSiteStatus(null);
						site.clearReadings();
						flag = true;
					}
				}
			}
		}
		return flag;
    }

    //Adds single reading to the given site and study then returns message.
    public String addReading(int studyID, String siteID, String readingID,
							 String readingDate, String readingType, String readingValue) {
        String message = null;


        Reading reading = new Reading();

        reading.setSite_id(siteID);
        reading.setReading_date(readingDate);
        reading.setReading_id(readingID);
        reading.setReading_type(readingType);
        reading.setReading_value(readingValue);

        for (Study study : studyList) {
            if(study.getStudyID() == studyID) {
                for (Site site : study.getSites()) {
                    if(site.getId() == siteID) {
                        if(site.getSiteStatus() == Site.siteStatus.ACTIVE_SITE) {
                            site.addReading(reading);
                           message = "Reading Added\n";
                        }else {
                          message = "Site not collecting. Start site collection to add reading.\n";
                        }
                    }
                }
            }
        }
		System.out.println(message);
        return message;
    }

    //Remove single reading from given study and site and return true if removed
    public boolean removeReading(int studyID, int siteID, String readingID) {
    	boolean flag = false;
    	for (Study study : studyList) {
			if(study.getStudyID() == studyID) {
				for (Site site : study.getSites()) {
					if(site.getId().equals(siteID)) {
						for (Reading reading : site.getReadings()) {
							if(reading.getReading_id() == readingID) {
								reading.setReading_date(null);
								reading.setReading_id(null);
								reading.setReading_type(null);
								reading.setSite_id(null);
								reading.setReading_value(null);
								flag = true;
							}
						}
					}
				}
			}
		}
		return flag;
    }

    //Get all readings stored in the application. returns array list of readings.
    public ArrayList<String> getAllReadings(){
    	ArrayList<String> arr = new ArrayList<>();
    	for (Study study : studyList) {
			for (Site site : study.getSites()) {
				for (Reading reading : site.getReadings()) {
					if(!site.getReadings().isEmpty()) {
						arr.add(reading.toString());
					}
				}
			}
    	}
		return arr;
    }

    public void setSiteStatus(int studyID, String siteID, Site.siteStatus siteStatus) {

    	for (Study study : studyList) {
			if(study.getStudyID() == studyID) {
				for (Site site : study.getSites()) {
					if(site.getId().equals(siteID)) {
						site.setSiteStatus(siteStatus);
						}
					}
				}
			}
		}

    //Returns list of active site that are able to have readings added to them.
    public ArrayList<Site> getActiveSites(int studyID) {
    	ArrayList<Site> activeSites = null;
		for (Study study : studyList) {
			if(study.getStudyID() == studyID) {
				for (Site site : study.getSites()) {
					if(site.getSiteStatus() == Site.siteStatus.ACTIVE_SITE) {
						activeSites.add(site);
					}
				}
			}
		}
		return activeSites;
    }

    //Returns list of all study ids in the app
    public List<String> getAllStudyIDs(){
    	List<String> studyIDs = new ArrayList<String>();
    	for (Study study : studyList) {
			studyIDs.add(Integer.toString(study.getStudyID()));
		}
		return studyIDs;
    }

    //Returns list of site ids for a given study
    public List<String> getAllSiteIDs(int studyID){
    	List<String> siteIDs = new ArrayList<>();
    	for (Study study : studyList) {
			if(study.getStudyID() == studyID) {
				for (Site site : study.getSites()) {
					siteIDs.add(site.getId());
				}
			}
		}
		return siteIDs;
    }

    public List<Study> retrieveStudies(){
    	/*for(Study study : studyList){
    		for(Site site : study.getSites()){
    			System.out.println(site.toString());
    			for(Reading reading : site.getReadings()){
    				System.out.println(reading.toString());
				}
			}
		}*/
        return studyList;
    }

}