package com.ics.part3.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.ics.part3.study.*;

import com.ics.part3.R;
import com.ics.part3.study.Record;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class StudyActivity extends AppCompatActivity {

    public static Record record = new Record();//  Stores all the data in the program
    public static int currentStudy;
    public static String currentSite;
    public static ArrayAdapter<String> adapter;
    public static Spinner studySelectSpinner;

    private AlertDialog dialog;



    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        addExampleJSON();
        importXMLFile();
        readFile();

        //Fill Test Data. USE THIS FOR TESTING ONLY.
        /*record.addStudy(1,"Study 1");
        record.addStudy(2,"Study 2");
        record.addStudy(3,"Study 3");

        record.addSite(1,10);
        record.addSite(1,20);
        record.addSite(1,30);
        record.addSite(2,40);
        record.addSite(2,50);
        record.addSite(2,60);
        record.addSite(3,70);
        record.addSite(3,80);
        record.addSite(3,90);

        record.setSiteStatus(1,10, Site.siteStatus.ACTIVE_SITE);
        record.setSiteStatus(1,20, Site.siteStatus.ACTIVE_SITE);
        record.setSiteStatus(1,30, Site.siteStatus.ACTIVE_SITE);
        record.setSiteStatus(2,40, Site.siteStatus.ACTIVE_SITE);
        record.setSiteStatus(2,50, Site.siteStatus.ACTIVE_SITE);
        record.setSiteStatus(2,60, Site.siteStatus.ACTIVE_SITE);
        record.setSiteStatus(3,70, Site.siteStatus.ACTIVE_SITE);
        record.setSiteStatus(3,80, Site.siteStatus.ACTIVE_SITE);
        record.setSiteStatus(3,90, Site.siteStatus.ACTIVE_SITE);


        record.addReading(1,10,"100", "1/2/2019", Reading.readingType.BAR_PRESS, "50");
        record.addReading(1,10,"200", "1/3/2019", Reading.readingType.BAR_PRESS, "810");
        record.addReading(1,10,"300", "1/4/2019", Reading.readingType.BAR_PRESS, "90");
        record.addReading(1,20,"400", "1/4/2019", Reading.readingType.HUMIDITY, "2062");
        record.addReading(1,20,"500", "1/4/2019", Reading.readingType.HUMIDITY, "65411");
        record.addReading(2,30,"600", "2/8/2019", Reading.readingType.HUMIDITY, "9");
        record.addReading(2,30,"700", "2/1/2019", Reading.readingType.HUMIDITY, "7984");
        record.addReading(2,30,"800", "3/1/2019", Reading.readingType.HUMIDITY, "432");
        record.addReading(2,40,"900", "6/1/2019", Reading.readingType.HUMIDITY, "21");
        record.addReading(2,50,"1000", "6/1/2019", Reading.readingType.HUMIDITY, "48");
        record.addReading(2,60,"1100", "8/1/2019", Reading.readingType.HUMIDITY, "48");
        record.addReading(2,60,"1200", "8/1/2019", Reading.readingType.HUMIDITY, "786");
        record.addReading(2,70,"1300", "8/1/2019", Reading.readingType.HUMIDITY, "4135");
        record.addReading(2,70,"1400", "8/1/2019", Reading.readingType.PARTICULATE, "783");
        record.addReading(3,70,"1500", "8/1/2019", Reading.readingType.PARTICULATE, "7835");
        record.addReading(3,80,"1600", "9/1/2019", Reading.readingType.PARTICULATE, "32");
        record.addReading(3,80,"1700", "10/1/2019", Reading.readingType.PARTICULATE, "7");
        record.addReading(3,80,"1800", "12/1/2019", Reading.readingType.PARTICULATE, "48");
        record.addReading(3,90,"1900", "12/1/2019", Reading.readingType.TEMP, "9456");
        record.addReading(3,90,"2000", "12/1/2019", Reading.readingType.TEMP, "73354");*/


        /*List<Study> studies = readFile();
        for(Study study : studies){
            System.out.println(study.toString());
        }*/
        /*for(Study study : studies){
            record.addStudy(study.getStudyID(), study.getStudyName());
            for(Site site : study.getSites()){
                record.addSite(study.getStudyID(), site.getId());
                for(Reading reading : site.getReadings()){
                    record.addReading(study.getStudyID(), site.getId(), reading.getReading_id(),
                            reading.getReading_date(),reading.getReading_type(),reading.getReading_value());
                }
            }
        }*/



        final AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);



        Button continueToSiteButton = (Button)findViewById(R.id.continueToSitebutton);
        continueToSiteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(studySelectSpinner.getSelectedItem() == null)
                {
                    builder.setMessage("Select a study or Add a new study").setTitle("No Study Selected error");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // User clicked OK button
                        }
                    });

                    dialog = builder.create();
                    dialog.show();
                } else {
                    startActivity(new Intent(StudyActivity.this, SiteActivity.class));

                }
            }
        });


        Button addNewStudyBtn = (Button)findViewById(R.id.createNewStudyButton);
        addNewStudyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(StudyActivity.this, AddNewStudyActivity.class));

            }
        });

        studySelectSpinner = (Spinner) findViewById(R.id.StudySelectSpinner);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, record.getAllStudyIDs());
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        studySelectSpinner.setAdapter(adapter);

        studySelectSpinner.setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    public void onItemSelected(AdapterView<?> parent, View view, int pos, long id) {

                        Object item = parent.getItemAtPosition(pos);
                        //System.out.println(item.toString());     //prints the text in spinner item.
                        currentStudy = Integer.parseInt(item.toString());
                    }
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });





        Button viewAll = (Button)findViewById(R.id.ViewAllstudiesButton);
        viewAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(StudyActivity.this, ViewAllActivity.class));

            }
        });


    }



    /**
     * imports example.json on start
     * List<Study>
     */
    private void readFile(){
        File sdCard = Environment.getExternalStorageDirectory();

        // retrieving json file
        File file = new File(sdCard, "/mydir/JSONFILE.json/");
        JSONParser parser = new JSONParser();
        try{
            Object obj = parser.parse(new FileReader((file)));
            JSONArray arrStudies = (JSONArray) obj;
            //System.out.println(studies);
            for(Object object : arrStudies){
                JSONObject study = (JSONObject) object;
                long studyID = (long) study.get("study_id");
                String studyName = (String) study.get("study_name");
                JSONArray arrStudyReadings = (JSONArray) study.get("study_readings");

                record.addStudy((int) studyID, studyName);
                Iterator i = arrStudyReadings.iterator();
                System.out.println("checking to see if there's anothing in arrStudy readings: " + arrStudyReadings);
                while(i.hasNext()){
                    JSONObject site = (JSONObject) i.next();
                    String siteID = (String) site.get("site_id:");
                    //System.out.println("site id is: " + siteID);

                    record.addSite((int) studyID, siteID);
                    JSONArray arrSiteReadings = (JSONArray) site.get("site_readings");
                    //System.out.println("checking to see if there's anything in arrSiteReadings: " + arrSiteReadings);
                    Iterator readings = arrSiteReadings.iterator();
                    record.setSiteStatus((int) studyID,siteID, Site.siteStatus.ACTIVE_SITE);
                    while(readings.hasNext()){
                        JSONObject reading = (JSONObject) readings.next();
                        String reading_date = (String) reading.get("reading_date");
                        String reading_id = (String) reading.get("reading_id");
                        String reading_type = (String) reading.get("reading_type");
                        String reading_value = (String) reading.get("reading_value");
                        String site_id = (String) reading.get("site_id");
                        record.addReading((int) studyID, site_id,
                                reading_id,reading_date,reading_type,reading_value);
                    }
                }
            }
            //List<Study> listOfStudies = new ArrayList<>();
        }catch (FileNotFoundException fnfe) {
            fnfe.printStackTrace();
        } catch (IOException ie) {
            ie.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    /**
     * imports the original example.json file and since the original file does not contain any studies
     * we will have to make a "unknown" study and label it as these
     */
    private List<Reading> importExampleJSON(){
        File sdCard = Environment.getExternalStorageDirectory();
        File file = new File(sdCard, "/mydir/example.json/");
        Gson gson = new Gson();
        try{
            BufferedReader reader = new BufferedReader(new FileReader(file));
            Site sample = gson.fromJson(reader, Site.class);
            //System.out.println("length is " + sample.getReadings().size());
            reader.close();
            return sample.getReadings();
        }catch(IOException ie){
            ie.printStackTrace();
        }
        return new ArrayList<>();
    }

    private void addExampleJSON(){
        List<Reading> readings = importExampleJSON();
        for(int i = 0; i < readings.size(); i++) {
            record.addStudy(0, "ANONYMOUS");
            record.addSite(0, readings.get(i).getSite_id());
            record.setSiteStatus(0,readings.get(i).getSite_id(), Site.siteStatus.ACTIVE_SITE);
            record.addReading(0,readings.get(i).getSite_id(),readings.get(i).getReading_id(), readings.get(i).getReading_date(),
                    readings.get(i).getReading_type(), readings.get(i).getReading_type());
        }
    }

    private Study importXMLFile(){
        Study newStudy = new Study();
        try{
            //get document builder
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            // parses the XML file
            File sdCard = Environment.getExternalStorageDirectory();
            File file = new File(sdCard, "/mydir/example.xml/");
            Document doc = builder.parse(file);


            // normalizes the XML structure
            // creates the structure of the xml file and makes it so it's in
            // tangent and aligned
            doc.getDocumentElement().normalize();


            // list containing readings
            List<Reading> listOfReadings = new ArrayList<>();
            // node list of readings
            NodeList readings = doc.getElementsByTagName("Reading");

            List<Site> sites = new ArrayList<>();


            // retrieves the study from the document xml
            //NodeList studies = doc.getElementsByTagName("Study");
            Node study = doc.getElementsByTagName("Study").item(0);
            //System.out.println(study.getTextContent());
            String readingStudy = study.getTextContent();
            Element eeElement = (Element) study;
            newStudy = new Study(eeElement.getAttribute("id"), readingStudy);

            for(int i = 0; i < readings.getLength(); i++){
                // individual reading
                Node reading = readings.item(i);
                if (reading.getNodeType() == Node.ELEMENT_NODE){
                    Element eElement = (Element) reading;
                    if (eElement.getElementsByTagName("Site").item(0) != null) {
                        String xmlSite = eElement.getElementsByTagName("Site").item(0).getTextContent();
                        //System.out.println("Site is: " + xmlSite);
                        String xmlType = eElement.getAttribute("type");
                        //System.out.println("Type is: " + xmlType);
                        String xmlID = eElement.getAttribute("id");
                        //System.out.println("id is " + xmlID);
                        String xmlValue = eElement.getAttribute("Value");
                        //System.out.println("value is " + xmlValue);
                        Reading read = new Reading(xmlSite, xmlType, xmlID, xmlValue);
                        //System.out.println(read.toString());
                        record.addStudy(newStudy.getStudyID(), newStudy.getStudyName());
                        record.addSite(newStudy.getStudyID(), read.getSite_id());
                        record.setSiteStatus(newStudy.getStudyID(),read.getSite_id(), Site.siteStatus.ACTIVE_SITE);
                        record.addReading(newStudy.getStudyID(), read.getSite_id(), read.getReading_id(),
                                read.getReading_date(),read.getReading_type(),read.getReading_value());

                    }
                }
            }

        }catch(Exception e){
            e.printStackTrace();
        }
        return newStudy;
    }

    private void addExampleXML(){
        Study study = importXMLFile();

    }


    @Override
    protected void onStop() {

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        //File sdCardFile = new File(StudyActivity.getFilesDir(), "example.json");
        List<Study> studies = record.retrieveStudies();
        String json = gson.toJson(studies);
        //System.out.println(json);
        //display(json);
        try {
            String FILENAME = "JSONFILE.json";
            // create folder in sd card called mydir
            File dir = new File(Environment.getExternalStorageDirectory() + "/mydir/");
            // create dir
            dir.mkdirs();
            System.out.println(dir.getAbsoluteFile());
            // store file in mydir
            File myFile = new File(dir, FILENAME);
            // write to jsonfile
            FileOutputStream fStream = new FileOutputStream(myFile);
            fStream.write(json.getBytes());
            fStream.close();

        } catch(FileNotFoundException fnfe){
            fnfe.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        super.onStop();  // Always call the superclass method first


    }


    }
