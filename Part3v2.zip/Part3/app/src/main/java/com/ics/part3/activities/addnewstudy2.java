package com.ics.part3.activities;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.ics.part3.study.*;

import static com.ics.part3.activities.StudyActivity.adapter;
import static com.ics.part3.activities.StudyActivity.currentStudy;
import static com.ics.part3.activities.StudyActivity.record;
import static com.ics.part3.activities.StudyActivity.studySelectSpinner;


import com.ics.part3.R;

import org.w3c.dom.Text;

public class addnewstudy2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addnewstudy2);

        Button okButton = (Button)findViewById(R.id.okButton);
        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                EditText idEdit   = (EditText) findViewById(R.id.StudyIdInput);

                EditText nameEdit = (EditText )findViewById(R.id.StudyNameInput);

                record.addStudy((Integer.parseInt((idEdit.getText().toString()))), (nameEdit.getText().toString()));

                adapter.add(idEdit.getText().toString());
                studySelectSpinner.setAdapter(adapter);


                startActivity(new Intent(addnewstudy2.this, StudyActivity.class));
            }
        });
    }
}
