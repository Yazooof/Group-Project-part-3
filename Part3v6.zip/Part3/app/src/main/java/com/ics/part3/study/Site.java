package com.ics.part3.study;

import com.google.gson.annotations.SerializedName;

import java.util.*;


public class Site {
	@SerializedName("site_id:")
	private String id;
	@SerializedName("site_readings")
	private List<Reading> readings;
	private siteStatus status;

	public enum siteStatus{
		ACTIVE_SITE, SITE_COLLECTION_DISABLED, SITE_INVALID, COMPLETED_STUDY;
	}

	public void setSiteStatus(siteStatus s) {
		status = s;
	}

	public siteStatus getSiteStatus() {
		return status;
	}


	public Site(){}

	/**
	 * Basic constructor, by default it has no readings, and no collection has started
	 * @param id
	 */
	public Site(String id) {
		this.id = id;
		this.readings = new ArrayList<>();
	}


	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the readings
	 */
	public List<Reading> getReadings() {
		return readings;
	}

	public void clearReadings() {
		this.readings = null;
	}

	/**
	 * @param reading the reading to add
	 */
	public void addReading(Reading reading) {
		this.readings.add(reading);
	}

	public void setReadings(List<Reading> readings){
	    this.readings = readings;
    }



}
