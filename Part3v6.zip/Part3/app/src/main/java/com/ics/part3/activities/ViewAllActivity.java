package com.ics.part3.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import com.ics.part3.study.*;

import com.ics.part3.R;

import static com.ics.part3.activities.StudyActivity.record;

public class ViewAllActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all);

        EditText e = (EditText) findViewById(R.id.viewAllTxt);

        for(String s : record.getAllReadings())  {
            e.append(s);
            e.append("\n");

            //System.out.println(s);

        }





        Button viewALlOK = (Button)findViewById(R.id.viewAllOKBtn);
        viewALlOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(ViewAllActivity.this, StudyActivity.class));

            }
        });

    }
}
