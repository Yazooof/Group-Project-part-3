package com.example.datacollection.fileIO;

import java.io.File;

/**
 * Decription: Class that sets up the file chooser for the Gui to accept a file
 *
 * @author hassanmumin
 *
 */
public class AcceptFile {

    /**
     * returns a List of sites
     *
     * @return
     */
    public File chooseFile() {
        File addedFile  = null;

        return addedFile;
    }

}