package com.ics.part3.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import static com.ics.part3.activities.StudyActivity.adapter;
import static com.ics.part3.activities.StudyActivity.record;
import static com.ics.part3.activities.StudyActivity.studySelectSpinner;


import com.ics.part3.R;

public class AddNewStudyActivity extends AppCompatActivity {


    private EditText idEdit;
    private EditText nameEdit;
    private AlertDialog dialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_study);


        idEdit   = (EditText) findViewById(R.id.StudyIdInput);
        nameEdit = (EditText )findViewById(R.id.StudyNameInput);

        final AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);



        Button addStudyBtn = (Button)findViewById(R.id.addStudyBtn);
        addStudyBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(idEdit.getText().toString().equalsIgnoreCase("") || nameEdit.getText().toString().equalsIgnoreCase(""))
                {
                    builder.setMessage("Enter a Study Name and a Study ID").setTitle("Error in Entry");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // User clicked OK button
                        }
                    });


                    dialog = builder.create();
                    dialog.show();
                } else
                {
                    record.addStudy((Integer.parseInt((idEdit.getText().toString()))), (nameEdit.getText().toString()));

                    adapter.add(idEdit.getText().toString());
                    studySelectSpinner.setAdapter(adapter);


                    startActivity(new Intent(AddNewStudyActivity.this, StudyActivity.class));
                }


            }
        });
    }
}
