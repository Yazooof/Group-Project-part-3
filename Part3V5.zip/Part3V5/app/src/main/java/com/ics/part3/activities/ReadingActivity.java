package com.ics.part3.activities;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.ics.part3.R;
import com.ics.part3.study.Reading;

import static com.ics.part3.activities.StudyActivity.currentSite;
import static com.ics.part3.activities.StudyActivity.currentStudy;
import static com.ics.part3.activities.StudyActivity.record;

public class ReadingActivity extends AppCompatActivity {
    String readingt;
    private AlertDialog dialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reading);

        final AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);

        Button readingButton = (Button)findViewById(R.id.readingBtn);
        readingButton.setOnClickListener(new View.OnClickListener() {

            EditText readingID   = (EditText) findViewById(R.id.readingID);
            EditText date   = (EditText) findViewById(R.id.date);
            EditText type  = (EditText) findViewById(R.id.typeID);
            EditText value   = (EditText) findViewById(R.id.valueID);

            @Override
            public void onClick(View v) {


                if(type.getText().toString().equalsIgnoreCase("") || readingID.getText().toString().equalsIgnoreCase("")
                || date.getText().toString().equalsIgnoreCase("") || value.getText().toString().equalsIgnoreCase("")) {

                    builder.setMessage("Fields cannot be empty").setTitle("Empty Field(s) Error");
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            // User clicked OK button
                        }
                    });

                    dialog = builder.create();
                    dialog.show();
                } else {
                    if(type.getText().toString().equalsIgnoreCase("TEMP")){
                        readingt = "TEMP";
                    }else if(type.getText().toString().equalsIgnoreCase("BAR_PRESS")){
                        readingt = "BAR_PRESS";
                    }else if(type.getText().toString().equalsIgnoreCase("HUMIDITY")){
                        readingt = "HUMIDITY";
                    }else if(type.getText().toString().equalsIgnoreCase("PARTICULATE")){
                        readingt = "PARTICULATE";
                    }
                    record.addReading(currentStudy,currentSite,readingID.getText().toString(),
                            date.getText().toString(),readingt,value.getText().toString());

                    Toast toast = Toast.makeText(getApplicationContext(), "Reading added", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.TOP,5,99);
                    toast.show();
                    readingID.setText("");
                    date.setText("");
                    type.setText("");
                    value.setText("");
                }

            }
            });

    }
}
