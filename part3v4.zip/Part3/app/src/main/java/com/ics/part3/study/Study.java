package com.ics.part3.study;

import com.google.gson.annotations.SerializedName;

import java.util.*;

/**
 * this class is a study of readings
 * @author Amadeus
 */
public class Study {

    private int studyID;
    private String studyName;
    @SerializedName("Sites")
    private ArrayList<Site> siteList = new ArrayList<>();

    public void addSite(Site site) {
    	siteList.add(site);
    }

    // creating a study without readings
    public Study(String studyID){
        this.studyID = this.studyID;
    }

    // creating a study with reading
    public Study(int studyID, ArrayList<Site> readings){
        this.studyID = studyID;
        this.siteList = readings;
    }

    public Study (int studyID, String studyName) {
    	this.studyID = studyID;
    	this.studyName = studyName;
    }

    // retrieving study
    public int getStudyID(){
        return studyID;
    }

    public void setStudyID(int studyID) {
    	this.studyID = studyID;
    }


    // if a study does not have readings then set it
    public void setReadings(ArrayList<Site> readings){
        this.siteList = readings;
    }

    // retrieving the readings
    public ArrayList<Site> getSites(){
        return siteList;
    }

    public String getStudyName() {
    	return studyName;
    }

    public void setStudyName(String studyName) {
    	this.studyName = studyName;
    }

    public String toString(){
        return "Study id: " + studyID + "\n"
                +"Study Name " + studyName + "\n";
    }
}