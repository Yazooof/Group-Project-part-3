package com.ics.part3.study;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class Studies {
    @SerializedName("")
    private List<Study> studies;

    public Studies(){
        // initializing studies arraylist
        this.studies = new ArrayList<>();
    }

    public List<Study> getStudies(){
        return studies;
    }
}
